import ForestHero from "@/components/ForestHero";

export default function MissionPage() {
  return <ForestHero />;
}
