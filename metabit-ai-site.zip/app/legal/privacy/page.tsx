export default function Privacy() {
  return (
    <div className="container py-16 prose max-w-3xl">
      <h1>Privacy Policy</h1>
      <p>We collect email addresses for updates when you submit the portal form. We use Plausible Analytics for privacy-friendly, cookie-light metrics.</p>
      <h2>Data</h2>
      <ul>
        <li>Email: stored by the chosen provider for communication and unsubscribable anytime.</li>
        <li>Web analytics: aggregated usage metrics; no invasive tracking.</li>
        <li>Cookies: used for consent preferences and essential session needs only.</li>
      </ul>
      <p>Contact: <a href="mailto:legal@example.com">legal@example.com</a></p>
    </div>
  );
}
