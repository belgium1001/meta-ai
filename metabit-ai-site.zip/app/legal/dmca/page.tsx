export default function DMCA() {
  return (
    <div className="container py-16 prose max-w-3xl">
      <h1>DMCA Policy &amp; Takedown</h1>
      <p>If you believe content here infringes your rights, send a notice including the copyrighted work, the infringing material URL, your contact info, and a statement under penalty of perjury.</p>
      <p>Email: <a href="mailto:dmca@example.com">dmca@example.com</a></p>
      <h2>Submit a Takedown Request</h2>
      <form className="space-y-4 max-w-xl">
        <label className="block">
          <span>Your Name</span>
          <input className="w-full border rounded px-3 py-2" required />
        </label>
        <label className="block">
          <span>Contact Email</span>
          <input type="email" className="w-full border rounded px-3 py-2" required />
        </label>
        <label className="block">
          <span>Work &amp; URLs</span>
          <textarea className="w-full border rounded px-3 py-2" rows={5} required />
        </label>
        <button className="px-4 py-2 rounded bg-primary.light text-white">Send</button>
      </form>
    </div>
  );
}
