export default function Terms() {
  return (
    <div className="container py-16 prose max-w-3xl">
      <h1>Terms of Use</h1>
      <p><strong>Ownership.</strong> © 2025 Metabit AI LLC. All content, code, and media on this site are owned by Metabit AI LLC unless otherwise noted.</p>
      <p><strong>Usage.</strong> You may browse and link to public pages. You may not copy, scrape, reproduce, or republish content without prior written permission.</p>
      <p><strong>Prohibited Conduct.</strong> No automated scraping, bulk downloads, or attempts to bypass technical protections.</p>
      <p><strong>Termination.</strong> We may suspend access for abuse. Legal rights, including IP protection and damages, are fully reserved.</p>
      <p><em>Note:</em> Technical measures (like watermarks and copy restrictions) deter casual copying; legal rights are the enforceable backbone.</p>
    </div>
  );
}
