import RainbowPortal from "@/components/RainbowPortal";

export default function Page() {
  return <RainbowPortal />;
}
