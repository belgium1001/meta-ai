import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  // TODO: integrate with ConvertKit or other provider.
  console.log("Subscribe request:", body);
  return NextResponse.json({ ok: true });
}
