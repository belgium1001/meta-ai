import "./globals.css";
import { Inter } from "next/font/google";
import { Metadata } from "next";
import Link from "next/link";
import Script from "next/script";
import OrbMenu from "@/components/OrbMenu";
import LegalStrip from "@/components/LegalStrip";
import CookieBanner from "@/components/CookieBanner";

export const metadata: Metadata = {
  title: "Metabit × AI",
  description: "In perfect harmony, we merge Metabit Unified Theory and AI to solve problems at every scale—especially for builders and entrepreneurs.",
  openGraph: {
    title: "Metabit × AI",
    description: "Metabit × AI: mission, weekly tools & projects, and a portal to join.",
    type: "website",
    url: "https://example.com",
  },
  metadataBase: new URL("https://example.com"),
};

const inter = Inter({ subsets: ["latin"] });

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/* Plausible analytics (replace data-domain) */}
        <Script defer data-domain="example.com" src="https://plausible.io/js/script.js" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "Metabit AI LLC",
              url: "https://example.com",
            }),
          }}
        />
        <link href="https://fonts.googleapis.com/css2?family=UnifrakturMaguntia&display=swap" rel="stylesheet" />
      </head>
      <body className={inter.className}>
        <a href="#main" className="skip-link">Skip to content</a>
        <OrbMenu />
        <main id="main" className="min-h-screen">{children}</main>
        <LegalStrip />
        <CookieBanner />
      </body>
    </html>
  );
}
