import LibraryShowcase from "@/components/LibraryShowcase";
import NewspaperBoard from "@/components/NewspaperBoard";

export default function ShowcasePage() {
  return (
    <div className="min-h-screen bg-[url('/images/library.jpg')] bg-cover bg-center pb-16">
      <div className="container py-16 space-y-12">
        <LibraryShowcase />
        <NewspaperBoard />
      </div>
    </div>
  );
}
