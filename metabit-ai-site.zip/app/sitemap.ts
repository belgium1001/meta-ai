import { MetadataRoute } from 'next';

export default function sitemap(): MetadataRoute.Sitemap {
  const base = 'https://example.com';
  return [
    { url: `${base}/`, lastModified: new Date() },
    { url: `${base}/mission`, lastModified: new Date() },
    { url: `${base}/showcase`, lastModified: new Date() },
    { url: `${base}/legal/terms`, lastModified: new Date() },
    { url: `${base}/legal/privacy`, lastModified: new Date() },
    { url: `${base}/legal/dmca`, lastModified: new Date() },
  ];
}
