"use client";
import { useEffect, useState } from "react";

type Project = { title: string; url: string; blurb: string };
type Weekly = { projects: Project[] };

export default function NewspaperBoard() {
  const [projects, setProjects] = useState<Project[]>([]);
  useEffect(() => {
    fetch("/data/weekly.json").then(r => r.json()).then((d: Weekly) => setProjects(d.projects || [])).catch(() => {});
  }, []);
  return (
    <section aria-label="Projects of the Week" className="glass rounded-2xl p-6">
      <h2 className="text-xl font-semibold text-white">Projects of the Week</h2>
      <div className="mt-4 grid md:grid-cols-3 gap-4">
        {projects.map((p, i) => (
          <a key={i} href={p.url} className="bg-white/80 rounded-xl p-4 hover:shadow-soft transition">
            <h3 className="font-semibold">{p.title}</h3>
            <p className="text-sm opacity-80 mt-1">{p.blurb}</p>
          </a>
        ))}
      </div>
      <p className="mt-3 text-white/90 text-sm">Each segment is like a newspaper snippet — click any card to learn more.</p>
    </section>
  );
}
