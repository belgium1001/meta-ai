"use client";
import React from "react";

export default function ProtectedText({ children }: { children: React.ReactNode }) {
  const onContext = (e: React.MouseEvent) => e.preventDefault();
  return (
    <div className="relative protected" onContextMenu={onContext}>
      <div aria-hidden className="wm select-none">METABIT × AI</div>
      <div>{children}</div>
    </div>
  );
}
