"use client";
import { useState } from "react";

export default function RainbowPortal() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/subscribe", { method: "POST", body: JSON.stringify({ email }) });
    setSent(true);
  };

  return (
    <section className="min-h-screen relative flex items-center justify-center">
      {/* soft rainbow ring */}
      <div className="w-[70vmin] h-[70vmin] rounded-full relative"
           style={{ backgroundImage: "conic-gradient(red, orange, yellow, green, cyan, blue, violet, red)" }}>
        <div className="absolute inset-[8%] bg-white rounded-full grid place-items-center shadow-soft">
          <form onSubmit={submit} className="w-full max-w-md px-6 text-center">
            <label htmlFor="email" className="block text-sm mb-1">Be the first to know. No spam. Unsubscribe anytime.</label>
            {!sent ? (
              <div className="flex gap-2">
                <input id="email" type="email" required className="flex-1 border rounded px-3 py-2" placeholder="you@example.com" value={email} onChange={(e)=>setEmail(e.target.value)} />
                <button className="px-4 py-2 rounded bg-primary.deep text-white">Join</button>
              </div>
            ) : (
              <p className="text-green-700 font-medium">Thanks! Check your inbox.</p>
            )}
          </form>
        </div>
      </div>
      <p className="absolute bottom-16 w-full text-center text-3xl font-black" style={{ fontFamily: "'UnifrakturMaguntia', serif", letterSpacing: ".04em" }}>
        Join the Metabit × AI Revolution.
      </p>
    </section>
  );
}
