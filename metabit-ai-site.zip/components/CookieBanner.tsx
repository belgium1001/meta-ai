"use client";
import { useEffect, useState } from "react";

export default function CookieBanner() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    if (typeof window !== "undefined") {
      setShow(localStorage.getItem("cookie-consent") !== "1");
    }
  }, []);
  if (!show) return null;
  return (
    <div role="dialog" aria-live="polite" className="fixed bottom-4 left-1/2 -translate-x-1/2 glass rounded-xl px-4 py-3 max-w-lg z-40">
      <p className="text-sm">We use minimal cookies to remember your preferences and keep things running smoothly.</p>
      <div className="mt-2 flex gap-2 justify-end">
        <button className="px-3 py-1 rounded bg-primary.deep text-white" onClick={() => { localStorage.setItem("cookie-consent", "1"); setShow(false); }}>Accept</button>
        <button className="px-3 py-1 rounded bg-white/70" onClick={() => setShow(false)}>Close</button>
      </div>
    </div>
  );
}
