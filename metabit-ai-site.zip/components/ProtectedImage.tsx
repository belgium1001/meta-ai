"use client";
import Image from "next/image";

export default function ProtectedImage({ src, alt, width, height }: { src: string; alt: string; width: number; height: number }) {
  const onContext = (e: React.MouseEvent) => e.preventDefault();
  return (
    <div className="relative protected" onContextMenu={onContext}>
      <div aria-hidden className="wm select-none">METABIT × AI</div>
      <Image src={src} alt={alt} width={width} height={height} />
    </div>
  );
}
