"use client";
import ProtectedText from "./ProtectedText";

export default function ForestHero() {
  return (
    <section
      className="min-h-screen bg-[url('/images/forest.jpg')] bg-cover bg-center relative"
      aria-label="Mission — forest clearing"
    >
      <div className="absolute inset-0 bg-black/20" />
      <div className="container relative z-10 flex items-center justify-center min-h-screen">
        <ProtectedText>
          <blockquote className="italic text-center text-2xl md:text-3xl lg:text-4xl text-white drop-shadow-lg max-w-3xl glass p-6 rounded-2xl">
            In perfect harmony, we merge a revolutionary new theory of everything called Metabit Unified theory and the latest breakthroughs in AI to solve problems at every scale — especially for builders and entrepreneurs.
          </blockquote>
        </ProtectedText>
      </div>
    </section>
  );
}
