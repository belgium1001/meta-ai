"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import ProtectedImage from "./ProtectedImage";

type Weekly = {
  week_of: string;
  tool: { name: string; type: string; url: string; thumb: string; blurb: string };
  projects: { title: string; url: string; blurb: string }[];
};

export default function LibraryShowcase() {
  const [data, setData] = useState<Weekly | null>(null);
  useEffect(() => {
    fetch("/data/weekly.json").then(r => r.json()).then(setData).catch(() => {});
  }, []);
  return (
    <section aria-label="Tool of the Week" className="glass rounded-2xl p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-white">Tool of the Week</h2>
        <span className="text-white/80">{data?.week_of ?? ""}</span>
      </div>
      <div className="mt-4 grid md:grid-cols-[2fr,3fr] gap-6 items-center">
        {/* TV frame */}
        <div className="relative w-full aspect-video bg-black rounded-2xl border border-white/30 overflow-hidden">
          <div className="absolute inset-3 rounded-xl bg-neutral-900 p-4 flex items-center justify-center">
            <ProtectedImage src={data?.tool.thumb ?? "/images/tools/metabit-planner.png"} alt="Tool preview" width={640} height={360} />
          </div>
        </div>
        {/* Card */}
        <div className="text-white">
          <h3 className="text-2xl font-bold">{data?.tool.name ?? "Loading..."}</h3>
          <p className="opacity-90 mt-2">{data?.tool.blurb ?? ""}</p>
          <a href={data?.tool.url ?? "#"} className="inline-block mt-4 px-4 py-2 rounded bg-primary.light text-white">Open</a>
        </div>
      </div>
    </section>
  );
}
