import Link from "next/link";

export default function LegalStrip() {
  return (
    <footer className="border-t bg-white/60 backdrop-blur-sm">
      <div className="container py-6 flex flex-col md:flex-row items-center justify-between gap-3 text-sm">
        <p>© 2025 Metabit AI LLC. All rights reserved.</p>
        <nav className="flex gap-4">
          <Link href="/legal/terms">Terms</Link>
          <Link href="/legal/privacy">Privacy</Link>
          <Link href="/legal/dmca">DMCA</Link>
        </nav>
      </div>
    </footer>
  );
}
