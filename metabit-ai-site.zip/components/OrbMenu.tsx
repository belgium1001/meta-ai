"use client";
import Link from "next/link";
import { useState } from "react";
import { motion } from "framer-motion";

export default function OrbMenu() {
  const [open, setOpen] = useState(false);
  return (
    <div className="fixed top-4 right-4 z-40">
      <button
        aria-label="Open main menu"
        aria-haspopup="true"
        aria-expanded={open}
        onClick={() => setOpen(!open)}
        className="relative w-14 h-14 rounded-full"
      >
        {/* Three colored rings */}
        <motion.span
          layout
          className="absolute inset-0 rounded-full"
          style={{ boxShadow: "0 0 var(--ring-blur) rgba(74,163,255,.35)" }}
          animate={{ rotate: open ? 180 : 0 }}
        >
          <span className="absolute inset-1 rounded-full border-2 border-primary.deep/70"></span>
          <span className="absolute inset-2 rounded-full border-2 border-primary.light/70"></span>
          <span className="absolute inset-3 rounded-full border-2 border-primary.accent/70"></span>
        </motion.span>
        <span className="sr-only">Toggle navigation</span>
      </button>
      {open && (
        <nav
          className="absolute right-0 mt-3 glass rounded-2xl p-3 w-56"
          aria-label="Main"
        >
          <ul className="grid gap-1">
            <li><Link className="block px-3 py-2 rounded hover:bg-white/40" href="/">Home</Link></li>
            <li><Link className="block px-3 py-2 rounded hover:bg-white/40" href="/mission">Mission</Link></li>
            <li><Link className="block px-3 py-2 rounded hover:bg-white/40" href="/showcase">Showcase</Link></li>
            <li><Link className="block px-3 py-2 rounded hover:bg-white/40" href="/legal/terms">Terms</Link></li>
          </ul>
        </nav>
      )}
    </div>
  );
}
