# Metabit × AI — 3-Page Site (Next.js + Tailwind)

This starter implements:
- Floating **three-layer Orb Menu**
- **/mission** forest scene with floating italic mission text
- **/showcase** cozy library with a TV (Tool of the Week) and newspaper segments (Projects)
- **/** landing with a **white portal surrounded by a rainbow** + email capture
- **Legal pack** (Terms, Privacy, DMCA), robots & sitemap
- Soft anti-copy wrappers for protected text/images
- Accessibility and SEO-friendly defaults

## Quick Start

```bash
npm install
npm run dev
# open http://localhost:3000
```

## Where to edit
- Weekly content: `public/data/weekly.json`
- Orb & components: `components/*`
- Pages: `app/*/page.tsx`
- Legal: `app/legal/*/page.tsx`
- Analytics domain: `app/layout.tsx` Plausible tag
- Email provider: implement `app/api/subscribe/route.ts`

## Notes
- Images are simple SVG placeholders; replace with your own high-res assets.
- Soft anti-copy is applied to the forest mission quote and tool image; adjust as needed.
