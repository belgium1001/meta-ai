/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: { deep: "#0b3d91", light: "#4aa3ff", accent: "#8a2be2" },
        accent: { mint: "#00ffaa", sun: "#ffd166", hot: "#ff006e" },
      },
      boxShadow: {
        'soft': '0 10px 30px rgba(0,0,0,0.15)',
      },
      backgroundImage: {
        'forest': "url('/images/forest.jpg')",
        'library': "url('/images/library.jpg')",
        'rainbow': "radial-gradient(circle at center, white 0%, white 18%, rgba(255,255,255,0) 19%), conic-gradient(from 0deg, red, orange, yellow, green, cyan, blue, violet, red)",
      }
    },
  },
  plugins: [],
};
